Run in VirtualBox

Run the script file in the command line with: bash script.sh

Make sure to have the Voice folder and flickr-api-keys.txt file in the same folder as the jar to run


Notes:

creationTermList.txt contains the creation information for the quiz (name,term), if some creations dont get created make sure to delete their entry from this file.

Back button functionalities havnt been fully implemented yet




Target audience: elderly

Background music from
""Stop" (blue mix)" 
by Ghost_k (Ghost Kollective)

2007 - Licensed under
Creative Commons
Attribution
